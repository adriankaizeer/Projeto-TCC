config = {
    'titulo': 'BLIND',
    'res': '500x300',
    'backgroundcolor': '#323232'
}
