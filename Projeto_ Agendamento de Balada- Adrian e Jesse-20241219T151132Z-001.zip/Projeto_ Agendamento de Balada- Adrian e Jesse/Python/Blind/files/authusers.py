# Criando minha tela de autenticação e registro.

import tkinter as tk
from globalUtils import config
from tkinter import messagebox
from db_utils import Database
import menu 


class Auth():
    def __init__(self, tela): 
        self.tela = tela
        self.tela.title(config['titulo'])
        self.tela.geometry(config['res'])
        self.tela.configure(background=config['backgroundcolor'])
        
        self.db = Database()
        self.db.execQuery('''
            CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL, 
            senha TEXT NOT NULL,
            cpf VARCHAR(11) NOT NULL UNIQUE,
            email TEXT NOT NULL UNIQUE, 
            ativo INTEGER NOT NULL, 
            tipo TEXT NOT NULL
            )'''
        )
        self.db.execQuery('INSERT OR IGNORE INTO usuarios(nome, senha, email, cpf, ativo, tipo) VALUES (?, ?, ?, ?, ?, ?)', ('jesse', '1234', 'wetzyo@gmail.com', '111.111.111-11', '0', 'admin'))

        self.authScreen()

    def authScreen(self):
        #self.closeAll()

     
    
        tk.Label(self.tela, text='NOME').grid(row=0, column=0, padx=5, pady=5)
        self.usuarioEntry = tk.Entry(self.tela)
        self.usuarioEntry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(self.tela, text='SENHA').grid(row=1, column=0, padx=5, pady=5)
        self.senhaEntry = tk.Entry(self.tela, show='*')
        self.senhaEntry.grid(row=1, column=1, padx=5, pady=5)
        
        tk.Label(self.tela, text='CPF').grid(row=2, column=0, padx=5, pady=5)
        self.cpfEntry = tk.Entry(self.tela)
        self.cpfEntry.grid(row=2, column=1, padx= 5, pady=5)

        tk.Label(self.tela, text='EMAIL').grid(row=3, column=0, padx=5, pady=5)
        self.emailEntry = tk.Entry(self.tela)
        self.emailEntry.grid(row=3, column=1, padx=5, pady=5)


        tk.Button(self.tela, text='Entrar', command = self.searchUser).grid(row=4, column=0,  columnspan=2, pady=5)
        tk.Button(self.tela, text='Cadastrar', command = self.insertUser).grid(row=5, column=0,  columnspan=2, pady=5)

    def authScreenAdm(self):
        #self.closeAll()

     
    
        tk.Label(self.tela, text='NOME').grid(row=0, column=0, padx=5, pady=5)
        self.usuarioEntry = tk.Entry(self.tela)
        self.usuarioEntry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(self.tela, text='SENHA').grid(row=1, column=0, padx=5, pady=5)
        self.senhaEntry = tk.Entry(self.tela, show='*')
        self.senhaEntry.grid(row=1, column=1, padx=5, pady=5)
        
        tk.Label(self.tela, text='CPF').grid(row=2, column=0, padx=5, pady=5)
        self.cpfEntry = tk.Entry(self.tela)
        self.cpfEntry.grid(row=2, column=1, padx= 5, pady=5)

        tk.Label(self.tela, text='EMAIL').grid(row=3, column=0, padx=5, pady=5)
        self.emailEntry = tk.Entry(self.tela)
        self.emailEntry.grid(row=3, column=1, padx=5, pady=5)


        tk.Button(self.tela, text='Cadastrar Admin', command = self.insertUser).grid(row=5, column=0,  columnspan=2, pady=5)

    def searchUser(self):
        nome = self.usuarioEntry.get()
        senha = self.senhaEntry.get()
        cpf = self.cpfEntry.get()
        email = self.emailEntry.get()
        
        
        retorno = self.db.fetchRemote('SELECT * FROM usuarios WHERE email = ? and senha = ?', (nome, senha))

        if retorno:
            id, nome, senha, cpf, email, ativo, tipo = retorno
            messagebox.showinfo(config['titulo'], f'Você entrou na sua conta, bem vindo(a) {nome}.')
            self.openMenu(tipo)
        else:
            messagebox.showerror(config['titulo'], 'Login ou senha incorretos.')

    def insertUser(self):
        nome = self.usuarioEntry.get()
        senha = self.senhaEntry.get()
        cpf = self.cpfEntry.get()
        email = self.emailEntry.get()
        
        retorno = self.db.fetchRemote('SELECT * FROM usuarios WHERE email = ? and senha = ?', (email, senha))

        if not retorno:
            if len(nome) >= 5 and len(senha) >= 5 and len(cpf) == 11 and  len(email) >= 6:    
                self.db.execQuery('INSERT INTO usuarios (nome, senha, cpf, email, ativo, tipo) VALUES (?, ?, ?, ?, ?, ?)', (nome, senha, cpf, email, '1', 'user'))
                messagebox.showinfo(config['titulo'], 'Você cadastrou a conta com sucesso.')
            else:
                messagebox.showerror(config['titulo'], 'Você deve inserir seus dados corretamente.')
        else:
            messagebox.showerror(config['titulo'], 'Essa conta já foi cadastrada.')

    def insertAdmin(self):
        nome = self.usuarioEntry.get()
        senha = self.senhaEntry.get()
        cpf = self.cpfEntry.get()
        email = self.emailEntry.get()
        
        retorno = self.db.fetchRemote('SELECT * FROM usuarios WHERE email = ? and senha = ?', (email, senha))

        if not retorno:
            if len(nome) >= 5 and len(senha) >= 5 and len(cpf) == 11 and  len(email) >= 6:    
                self.db.execQuery('INSERT INTO usuarios (nome, senha, cpf, email, ativo, tipo) VALUES (?, ?, ?, ?, ?, ?)', (nome, senha, cpf, email, '1', 'admin'))
                messagebox.showinfo(config['titulo'], 'Você cadastrou a conta admin com sucesso.')
            else:
                messagebox.showerror(config['titulo'], 'Você deve inserir seus dados corretamente.')
        else:
            messagebox.showerror(config['titulo'], 'Essa conta já foi cadastrada.')

    def openMenu(self, tipo):
        if tipo == "admin":
            self.closeAll()
            self.tela.destroy()
            menu_app = MenuApp()
        elif tipo == "user":
            self.closeAll()
            self.tela.destroy()
            menu_app = ListaClientes()
        else:
            messagebox.showerror("Erro", "Tipo de usuário inválido.")
            
    def closeAll(self):
        for widget in self.tela.winfo_children():
            widget.destroy()

if __name__ == "__main__":
    tela = tk.Tk()
    app = Auth(tela)
    tela.mainloop()