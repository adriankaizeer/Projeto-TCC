import tkinter as tk
from tkinter import *
from globalUtils import config
from treeview import ListaClientes
from treeview import ListaAdmin
import os

class MenuApp:
    def __init__(self):
        self.app = Tk()
        self.app.title(config['titulo'])  
        self.app.geometry(config['res'])  
        self.app.configure(bg=config['backgroundcolor'])  
        self.mainMenu = Menu(self.app)
        self.app.config(menu=self.mainMenu)
        self.cadastroMenu = Menu(self.mainMenu, tearoff=0)  
        self.mainMenu.add_command(label="Funcionarios", command=self.funcionarios)
        self.mainMenu.add_command(label="Eventos", command=self.eventos)
        self.mainMenu.add_command(label="Clientes", command=self.clientes)
        self.mainMenu.add_separator() 
        self.mainMenu.add_cascade(label="Cadastros", menu=self.cadastroMenu)
        self.cadastroMenu.add_command(label="Cadastro Funcionarios", command=self.cadastroFuncionarios)
        self.cadastroMenu.add_command(label="Cadastro Eventos", command=self.cadastroEventos)
        self.label = tk.Label(self.app, text="Bom Trabalho.", font=("Helvetica", 20, "bold"), fg="white", bg="#323232")
        self.label.pack(padx=20, pady=20)  
        self.app.mainloop()

def funcionarios(self):
    tela = tk.Tk()
    lista = ListaAdmin(tela)
    tela.mainloop()

def eventos(self):
    print("Eventos selected") # Mudar para a logica do eventos, possivelmente uma treeview acessando a tabela eventos.

def clientes(self):
    tela = tk.Tk()
    lista = ListaClientes(tela)
    tela.mainloop()

def cadastroFuncionarios(self):
    print("Cadastro Funcionarios selected") # mudar a logica fazendo uma combobox fazendo o administrador escolher entre 0 e 1, admin ou user
        

def cadastroEventos(self):
    print("Cadastro Eventos selected") # uma tela que pede apenas titulo hora e valor do evento.
    
def sair(self):
    self.master.destroy()

