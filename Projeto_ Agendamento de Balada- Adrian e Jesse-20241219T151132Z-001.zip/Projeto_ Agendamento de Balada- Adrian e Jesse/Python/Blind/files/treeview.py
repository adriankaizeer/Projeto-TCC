import tkinter as tk
from tkinter import ttk,  messagebox
from db_utils import Database
from globalUtils import config


class ListaClientes:
    def __init__(self, tela):
        self.tela = tela
        self.tela.title(config['titulo'])
        self.tela.geometry(config['res'])
        self.tela.configure(background=config['backgroundcolor'])

        self.db = Database()
        tot_clientes = self.db.fetchAll('SELECT * FROM usuarios')

        self.tree = ttk.Treeview(self.tela,columns=("ID", "Nome", "Senha", "CPF", 'Email', 'Ativo', 'Tipo'),show="headings")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Nome", text="Nome")
        self.tree.heading("Senha", text="Senha")
        self.tree.heading("CPF", text="CPF")
        self.tree.heading("Email", text="Email")
        self.tree.heading("Ativo", text="Ativo")
        self.tree.heading("Tipo", text="Tipo")

        for cont_cliente in tot_clientes:
            self.tree.insert("", tk.END, values=cont_cliente)

        self.tree.pack()

        self.excluir_button = tk.Button(tela, text="Excluir", command=self.botao_excluir)
        self.excluir_button.pack()

        self.alterar_button = tk.Button(tela, text="Alterar", command=self.botao_alterar)
        self.alterar_button.pack()

    def botao_excluir(self):
        try:
            item_selecionado = self.tree.selection()[0]
            if len(item_selecionado) <= 0:
                self.tela.messagebox.showinfo(config['titulo'], "Selecione uma linha")
            else:
                self.db = Database()
                id_cliente = self.tree.item(item_selecionado, "values")[0]
                self.db.execQuery("DELETE FROM usuarios WHERE id = ?", (id_cliente,))
                self.tree.delete(item_selecionado)
                messagebox.showinfo(config['titulo'], "Cliente excluído com sucesso.")
        except IndexError:
            messagebox.showwarning(config['titulo'], "Selecione um cliente para excluir.")

    def botao_alterar(self):
        try:
            item_selecionado = self.tree.selection()
            if len(item_selecionado) <= 0:
                messagebox.showinfo(self.titulo, "Selecione uma linha")
            else:
                item_selecionado = item_selecionado[0]
                id_cliente = self.tree.item(item_selecionado, "values")[0]
                self.db = Database()
                cliente = self.db.fetchRemote("SELECT * FROM usuarios WHERE id = ?", (id_cliente,))
               
       

                # Crie uma nova janela para edição
                janela_editar = tk.Toplevel(self.tela)
                janela_editar.geometry(config['res'])
                janela_editar.title(config['titulo'])

                # Crie campos de entrada para os dados do cliente
                idlabel = tk.Label(janela_editar, text="Codigo")
                idlabel.pack()
                idlabel1 = tk.Label(janela_editar, text=id_cliente)
                idlabel1.pack()

                nome_label = tk.Label(janela_editar, text="Nome:")
                nome_label.pack()
                nome_entry = tk.Entry(janela_editar)
                nome_entry.insert(0, cliente[1])
                nome_entry.pack()

                email_label = tk.Label(janela_editar, text="Senha:")
                email_label.pack()
                email_entry = tk.Entry(janela_editar)
                email_entry.insert(0, cliente[2])
                email_entry.pack()

                senha_label = tk.Label(janela_editar, text="CPF:")
                senha_label.pack()
                senha_entry = tk.Entry(janela_editar)
                senha_entry.insert(0, cliente[3])
                senha_entry.pack()

                def botao_gravar():
                    novo_nome = nome_entry.get()
                    novo_email = email_entry.get()
                    nova_senha = senha_entry.get()
                    self.db = Database()
                    # para mostrar valores para teste print(id_cliente, novo_nome, novo_email, nova_senha)
                    self.db.execQuery("UPDATE usuarios SET nome = ?, email = ?, senha = ? WHERE id = ?",
                              (novo_nome, novo_email, nova_senha, id_cliente))
                    messagebox.showinfo(config['titulo'], f'Você alterou os dados da conta {id_cliente}')

                    self.tree.item(item_selecionado, values=(id_cliente, novo_nome, novo_email))

                gravar_button = tk.Button(janela_editar, text="Gravar", command= lambda: [botao_gravar()])
                gravar_button.pack()

                sair_button = tk.Button(janela_editar, text="Voltar", command=janela_editar.destroy)
                sair_button.pack()



        except IndexError:
            tk.messagebox.showwarning(self.titulo,
                                      "Selecione um cliente para editar.")


class ListaAdmin:
    def __init__(self, tela):
        self.tela = tela
        self.tela.title(config['titulo'])
        self.tela.geometry(config['res'])
        self.tela.configure(background=config['backgroundcolor'])

        self.db = Database()
        tot_clientes = self.db.fetchAll('SELECT * FROM usuarios WHERE tipo = ?', ('admin',))


        self.tree = ttk.Treeview(self.tela,
                            columns=("ID", "Nome", "Senha", "CPF", 'Email', 'Ativo', 'Tipo'),
                            show="headings")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Nome", text="Nome")
        self.tree.heading("Senha", text="Senha")
        self.tree.heading("CPF", text="CPF")
        self.tree.heading("Email", text="Email")
        self.tree.heading("Ativo", text="Ativo")
        self.tree.heading("Tipo", text="Tipo")

        for cont_cliente in tot_clientes:
            self.tree.insert("", tk.END, values=cont_cliente)

        self.tree.pack()

        self.excluir_button = tk.Button(tela, text="Excluir", command=self.botao_excluir)
        self.excluir_button.pack()

        self.alterar_button = tk.Button(tela, text="Alterar", command=self.botao_alterar)
        self.alterar_button.pack()

    def botao_excluir(self):
        try:
            item_selecionado = self.tree.selection()[0]
            if len(item_selecionado) <= 0:
                self.tela.messagebox.showinfo(config['titulo'], "Selecione uma linha")
            else:
                self.db = Database()
                id_cliente = self.tree.item(item_selecionado, "values")[0]
                self.db.execQuery("DELETE FROM usuarios WHERE id = ?", (id_cliente,))
                self.tree.delete(item_selecionado)
                messagebox.showinfo(config['titulo'], "Cliente excluído com sucesso.")
        except IndexError:
            messagebox.showwarning(config['titulo'], "Selecione um cliente para excluir.")

    def botao_alterar(self):
        try:
            item_selecionado = self.tree.selection()
            if len(item_selecionado) <= 0:
                messagebox.showinfo(self.titulo, "Selecione uma linha")
            else:
                item_selecionado = item_selecionado[0]
                id_cliente = self.tree.item(item_selecionado, "values")[0]
                self.db = Database()
                cliente = self.db.fetchRemote("SELECT * FROM usuarios WHERE id = ?", (id_cliente,))
                janela_editar = tk.Toplevel(self.tela)
                janela_editar.geometry(config['res'])
                janela_editar.title(config['titulo'])
                idlabel = tk.Label(janela_editar, text="Codigo")
                idlabel.pack()
                idlabel1 = tk.Label(janela_editar, text=id_cliente)
                idlabel1.pack()

                nome_label = tk.Label(janela_editar, text="Nome:")
                nome_label.pack()
                nome_entry = tk.Entry(janela_editar)
                nome_entry.insert(0, cliente[1])
                nome_entry.pack()

                email_label = tk.Label(janela_editar, text="Senha:")
                email_label.pack()
                email_entry = tk.Entry(janela_editar)
                email_entry.insert(0, cliente[2])
                email_entry.pack()

                senha_label = tk.Label(janela_editar, text="CPF:")
                senha_label.pack()
                senha_entry = tk.Entry(janela_editar)
                senha_entry.insert(0, cliente[3])
                senha_entry.pack()

                def botao_gravar():
                    novo_nome = nome_entry.get()
                    novo_email = email_entry.get()
                    nova_senha = senha_entry.get()
                    self.db = Database()
                    self.db.execQuery("UPDATE usuarios SET nome = ?, email = ?, senha = ? WHERE id = ?",(novo_nome, novo_email, nova_senha, id_cliente))
                    messagebox.showinfo(config['titulo'], f'Você alterou os dados da conta {id_cliente}')
                    self.tree.item(item_selecionado, values=(id_cliente, novo_nome, novo_email))
                gravar_button = tk.Button(janela_editar, text="Gravar", command= lambda: [botao_gravar()])
                gravar_button.pack()
                sair_button = tk.Button(janela_editar, text="Voltar", command=janela_editar.destroy)
                sair_button.pack()



        except IndexError:tk.messagebox.showwarning(self.titulo,"Selecione um cliente para editar.")

