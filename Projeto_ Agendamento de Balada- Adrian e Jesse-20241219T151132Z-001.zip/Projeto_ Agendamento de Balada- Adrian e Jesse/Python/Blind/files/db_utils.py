# Vou criar um arquivo chamado db_utils para conter todo o conteudo sobre banco de dados que eu preciso.
# no caso do meu TCC, 'Blind' vou fazer um CRUD basico.

import sqlite3 

class Database:
    def __init__(self, db = 'blind.db'): # Criando a função inicio, já vou definir o db dentro dos parametros.
        self.db = db # Adiciono dentro da class meu banco no qual vai ser utilizado.

    def execQuery(self, query, parametros=()): # Criando a função para consultar.
        with sqlite3.connect(self.db) as conn: # Utilizando meu DB salvo no parametro vou 'apelida-lo' de conn para facilitar.
            cursor = conn.cursor() # Vou criar o cursor do meu db. 
            cursor.execute(query, parametros) # com a variavel 'cursor' vou executar os itens query e parametros no qual vai ser solicitado nas outras telas.
            conn.commit() # obtenho o valor dessa execução.
            return cursor # já aqui vou retornar o valor dessa pesquisa quando a função for finalizada, assim me permitindo utiliza-la em outras telas.
        
    def fetchRemote(self, query, parametros=()):
        with sqlite3.connect(self.db) as conn:
            cursor = conn.cursor()
            cursor.execute(query, parametros)
            return cursor.fetchone() 
        
    def fetchAll(self, query, parametros=()):
        with sqlite3.connect(self.db) as conn:
            cursor = conn.cursor()
            cursor.execute(query, parametros)
            return cursor.fetchall()