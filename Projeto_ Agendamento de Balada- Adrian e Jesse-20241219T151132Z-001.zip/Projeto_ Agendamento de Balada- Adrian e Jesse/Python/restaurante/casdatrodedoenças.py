import tkinter  as  TK
from tkinter import messagebox
import  sqlite3

class cadastro:
  def __init__ (self, tela):
    self.tela = tela
    titulo= "Cadastro de Doenças"
    self.titulo = titulo
    self.tela.title(self.titulo)
    self.tela.geometry ("300x300")
    self.conn = sqlite3.connect ("restaurante.db")
    self.cursor = self.conn.cursor()
    self.cursor.execute("""CREATE TABLE IF NOT EXISTS  doencas(ID INTEGER PRIMARY KEY, nome TEXT, ativo TEXT)""")

    self.nomelabel= TK.Label (self.tela, text="nome")
    self.nomelabel.pack()
    self.nomeentry= TK.Entry (tela,  width=30)
    self.nomeentry.pack()

    self.ativolabel= TK.Label (self.tela, text="ativo")
    self.ativolabel.pack()
    self.ativoentry= TK.Entry (tela,  width=30)
    self.ativoentry.pack()
    self.nomelabel= TK.Label (self.tela, text="tipo")
    self.nomelabel.pack()
    self.nomeentry= TK.Entry (tela,  width=30)
    self.nomeentry.pack()

    self.cadastrarbuton = TK.Button(self.tela,text="cadastrar", command = self.cadastrar)
    self.cadastrarbuton.pack ()


  def cadastrar (self):
    nome = self.nomeentry.get()
    ativo = self.ativoentry.get()

    self.cursor.execute("INSERT INTO doencas(nome, ativo, tipo) VALUES (?, ?, ?)", (nome,ativo))

    self.conn. commit()
    restaurante = self.cursor.fetchone()
    if restaurante:
      messagebox.showinfo(self.titulo, "Cadastro concluido")
    else:
      messagebox.showinfo (self.titulo, "Erro no Cadastro, tente novamente")

if __name__ == "__main__":
  tela= TK.Tk ()
  acesso= cadastro(tela)
  tela.mainloop()
