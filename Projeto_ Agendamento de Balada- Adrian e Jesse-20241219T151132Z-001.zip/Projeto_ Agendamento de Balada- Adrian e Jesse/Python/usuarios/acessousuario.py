import tkinter as tk
from tkinter import messagebox
import sqlite3

class LoginSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Login")
        self.root.geometry("300x200")
        self.conn = sqlite3.connect("usuarios.db")
        self.cursor = self.conn.cursor()
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuario (
        id INTEGER PRIMARY KEY,
        nome TEXT,
        email TEXT,
        senha TEXT
        )
        """)
        self.nome_label = tk.Label(root, text="Nome: ")
        self.nome_label.pack()
        self.nome_entry = tk.Entry(root, width=30)
        self.nome_entry.pack()
        self.email_label = tk.Label(root, text="Email:")
        self.email_label.pack()
        self.email_entry = tk.Entry(root, width=30)
        self.email_entry.pack()
        self.senha_label = tk.Label(root, text="Senha:")
        self.senha_label.pack()
        self.senha_entry = tk.Entry(root, width=30, show="*")
        self.senha_entry.pack()
        self.login_button = tk.Button(root, text="Login", command=self.login)
        self.login_button.pack()
        self.cadastro_button = tk.Button(root, text="Cadastrar", command=self.cadastro)
        self.cadastro_button.pack()
    def login(self):
        nome = self.nome_entry.get()
        email = self.email_entry.get()
        senha = self.senha_entry.get()
        if len(email.strip()) <= 0 and len(senha.strip()) <= 0:
            messagebox.showinfo("Sistema de Login", "Campos obrigatórios não preenchidos")
        else:
            self.cursor.execute("SELECT * FROM usuario WHERE email=? AND senha=?", (email, senha))
            usuario = self.cursor.fetchone()
            if usuario:
                messagebox.showinfo("Sistema de Login", "Bem-Vindo, " + nome)
                self.root.destroy()
                
            else:
                messagebox.showerror("Sistema de Login", "Email ou senha incorretos")
    def cadastro(self):
        nome = self.nome_entry.get()
        email = self.email_entry.get()
        senha = self.senha_entry.get()
        if len(email.strip()) <= 0 and len(senha.strip()) <= 0:
            messagebox.showinfo("Sistema de Login", "Campos obrigatórios não preenchidos") 
        else:
            self.cursor.execute(
                "INSERT INTO usuario (nome, email, senha) VALUES (?, ?, ?)", (nome, email, senha)
            )
            self.conn.commit()
            usuario = self.cursor.fetchone()
            if usuario:
                messagebox.showinfo("Sistema de Login", "Cadastro realizado com sucesso")
            else:
                messagebox.showerror("Sistema de Login", "Não foi possível cadastrar")
if __name__ == "__main__":
    root = tk.Tk()
    acesso = LoginSystem(root)
    root.mainloop()
