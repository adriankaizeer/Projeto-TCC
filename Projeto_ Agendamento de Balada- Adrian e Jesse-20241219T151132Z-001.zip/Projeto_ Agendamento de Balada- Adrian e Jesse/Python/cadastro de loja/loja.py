import tkinter as tk
from tkinter import messagebox
import sqlite3


class Acesso:

    def __init__(self):
        self.tela = tk.Tk()
        self.tela.title("Cadastro de Lojas de Roupas")
        self.tela.geometry("300x300")

       
        self.conn = sqlite3.connect("lojas.db")
        self.cursor = self.conn.cursor()
        self.cursor.execute("""CREATE TABLE IF NOT EXISTS lojas (
                               id INTEGER PRIMARY KEY,
                               nome TEXT,
                               marca TEXT,
                               preco TEXT)""")

        
        tk.Label(self.tela, text="Nome:").pack()
        self.nomeentry = tk.Entry(self.tela)
        self.nomeentry.pack()

        tk.Label(self.tela, text="Marca:").pack()
        self.marcaentry = tk.Entry(self.tela)
        self.marcaentry.pack()

        tk.Label(self.tela, text="Preço:").pack()
        self.precoentry = tk.Entry(self.tela)
        self.precoentry.pack()

        tk.Button(self.tela, text="Acessar", command=self.acessar).pack()
        tk.Button(self.tela, text="Cadastrar", command=self.cadastrar).pack()

        self.tela.mainloop()

    def acessar(self):
        nome = self.nomeentry.get()
        marca = self.marcaentry.get()

        if not nome or not marca:
            messagebox.showinfo("Erro", "Preencha todos os campos!")
            return

        self.cursor.execute("SELECT * FROM lojas WHERE nome=? AND marca=?", (nome, marca))
        loja = self.cursor.fetchone()

        if loja:
            messagebox.showinfo("Bem-vindo", f"Loja encontrada: {loja[1]}")
        else:
            messagebox.showerror("Erro", "Loja não encontrada!")

    def cadastrar(self):
        nome = self.nomeentry.get()
        marca = self.marcaentry.get()
        preco = self.precoentry.get()

        if not nome or not marca or not preco:
            messagebox.showinfo("Erro", "Preencha todos os campos!")
            return

        self.cursor.execute("INSERT INTO lojas (nome, marca, preco) VALUES (?, ?, ?)", (nome, marca, preco))
        self.conn.commit()
        messagebox.showinfo("Sucesso", "Loja cadastrada com sucesso!")



Acesso()