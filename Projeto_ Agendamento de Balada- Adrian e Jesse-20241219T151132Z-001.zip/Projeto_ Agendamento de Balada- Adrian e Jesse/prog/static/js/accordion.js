document.querySelectorAll('.accordion-1').forEach(item => {
    item.addEventListener('click', () => {
        const isActive = item.classList.contains('active');

        document.querySelectorAll('.accordion-1').forEach(acc => {
            acc.classList.remove('active');
            acc.nextElementSibling.classList.remove('active'); 
        });


        if (!isActive) {
            item.classList.add('active');
            const text = item.nextElementSibling;
            text.classList.add('active'); 
        }
    });
});
