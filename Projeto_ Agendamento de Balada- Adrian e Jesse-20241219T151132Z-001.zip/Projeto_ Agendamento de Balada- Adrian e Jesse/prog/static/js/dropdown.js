document.querySelectorAll('.click-logged').forEach(trigger => {
    trigger.addEventListener('click', (event) => {
        const dropdownContainer = trigger.nextElementSibling; // Obtém o contêiner dropdown correspondente
        const isActive = dropdownContainer.classList.contains('active');

        // Remove a classe 'active' de todos os dropdowns
        document.querySelectorAll('.dropdown-container').forEach(dropdown => {
            dropdown.classList.remove('active');
        });

        // Se o dropdown não está ativo, ative-o
        if (!isActive) {
            dropdownContainer.classList.add('active');
        }

        // Previne que o clique no dropdown feche o menu
        event.stopPropagation();
    });
});

// Fechar dropdown ao clicar fora
window.addEventListener('click', (event) => {
    if (!event.target.matches('.click-logged')) {
        document.querySelectorAll('.dropdown-container').forEach(dropdown => {
            dropdown.classList.remove('active');
        });
    }
});