document.getElementById('checkLoginBtn').addEventListener('click', checkLoginStatus);

function checkLoginStatus() {
    // Simulação de verificação de login
    const isLoggedIn = false; // Aqui você pode substituir por uma verificação real

    if (!isLoggedIn) {
        openPopup();
    } else {
        alert('Você já está logado!');
    }
}

function openPopup() {
    document.getElementById('popup').style.display = 'block';
}

document.getElementById('closePopup').addEventListener('click', function() {
    document.getElementById('popup').style.display = 'none';
});





window.addEventListener('click', function(event) {
    const popup = document.getElementById('popup');
    if (event.target === popup) {
        popup.style.display = 'none';
    }
});