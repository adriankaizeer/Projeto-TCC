document.addEventListener('DOMContentLoaded', function() {
    const notifications = document.querySelectorAll('.notification');
    
    notifications.forEach(notification => {
        setTimeout(() => {
            notification.style.opacity = '0'; 
            setTimeout(() => {
                notification.remove(); 
            }, 500); // tempo do CSS
        }, 3000); 
    });
});