var userLoggedIn = {{ user_logged_in | tojson }};
    console.log(userLoggedIn); // Isso exibirá o valor no console

    if (userLoggedIn) {
        console.log("Usuário está logado.");
        alert('Usuário logado');
    } else {
        console.log("Usuário não está logado.");
        alert('Usuário não está logado');
    }