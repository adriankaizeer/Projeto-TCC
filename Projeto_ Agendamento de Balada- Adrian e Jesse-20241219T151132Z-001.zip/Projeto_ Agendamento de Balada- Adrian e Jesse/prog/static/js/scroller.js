document.getElementById('scrollButton').addEventListener('click', function() {
    document.getElementById('section2').scrollIntoView({
        behavior: 'smooth' 
    });
});