function aplicarMascaraCPF(cpf) {
    cpf = cpf.replace(/\D/g, '');
    

    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
    cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2');

    return cpf;
}

document.addEventListener('DOMContentLoaded', function() {
    const cpfInput = document.getElementById('cpf');
    cpfInput.addEventListener('input', function() {
        this.value = aplicarMascaraCPF(this.value);
    });
});