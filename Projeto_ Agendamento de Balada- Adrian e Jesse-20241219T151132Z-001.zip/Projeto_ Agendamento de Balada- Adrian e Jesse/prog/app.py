import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, g, session
database = 'database/blind.db'

app = Flask(__name__)  
app.secret_key = 'tcczika'  


######################################## Funções uteis ######################################

def get_db():
    db = getattr(g, '_blind', None)
    if db is None:
        db = g._blind = sqlite3.connect(database)
        db.row_factory = sqlite3.Row  
    return db 


@app.teardown_appcontext
def close_connection(exception):
    db = g.pop('_blind', None)
    if db is not None:
        db.close()


@app.route('/', methods=['GET'])
def index():
    user_logged_in = 'user_id' in session  # Verifica se o usuário está logado
    return render_template('index.html', user_logged_in=user_logged_in)


def create_table():
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        cursor.execute(''' 
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                senha TEXT NOT NULL,
                cpf VARCHAR UNIQUE NOT NULL,
                numero VARCHAR UNIQUE NOT NULL
            )
        ''')
        db.commit()
####################################################################################################

######################################## Rotas e Templates #########################################

@app.route('/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)  # Remove o ID do usuário da sessão
    session.pop('user_email', None)
    session.pop('user_nome', None)  # Remove o e-mail da sessão
    session.pop('user_numero', None) #Remove o numero da sessão
    flash('Você saiu com sucesso.')  # Mensagem de logout
    return redirect(url_for('index'))  # Redireciona para a página inicial


@app.route('/login', methods=['GET', 'POST'])
def login():
    # Verifica se o usuário já está logado
    if 'user_id' in session:  # Esta verificação deve ser feita logo no início
        flash('Você já está logado.')
        return redirect(url_for('index'))  # Redireciona para a página inicial se já logado

    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('password')

        if email and senha:
            db = get_db()
            cursor = db.cursor()
            cursor.execute('SELECT * FROM usuarios WHERE email = ? AND senha = ?', (email, senha))
    
            retorno = cursor.fetchone()
            print(retorno)
       
            if retorno:
                session['user_id'] = retorno['id']  # Armazena o ID do usuário na sessão
                session['user_email'] = retorno['email']  # Armazena o e-mail na sessão
                session['user_nome'] = retorno['nome']
                session['user_numero'] = retorno['numero']

                
                flash('Login realizado com sucesso!')
                return redirect(url_for('index'))  # Redireciona para a página inicial após login bem-sucedido
            else:
                flash('Usuário ou senha incorretos.')
        else:
            flash('Preencha todos os campos.')

    return render_template('login.html')  # Renderiza a página de login para requis


@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nome = request.form.get('nome')
        email = request.form.get('email')
        senha = request.form.get('password')
        cpf = request.form.get('cpf')
        numero = request.form.get('numero')
        
        if email and senha and cpf and numero:
            if len(email) >= 6:
                if len(senha) >= 6:
                    if cpf and numero:
                        db = get_db()
                        cursor = db.cursor()  
                        cursor.execute('SELECT * FROM usuarios WHERE email = ? AND cpf = ?', (email, cpf))
                        retorno = cursor.fetchone()  
                        if retorno:
                            flash('O CPF ou Email Informado já está cadastrado.')
                        else:
                            cursor.execute('INSERT INTO usuarios (nome, email, senha, cpf, numero) VALUES (?, ?, ?, ?, ?)', (nome, email, senha, cpf, numero))
                            db.commit()  
                            flash('Cadastro realizado com sucesso.')
                            return redirect(url_for('login')) 
                    else:
                        flash('CPF Incorreto favor analisar.')
                else:
                    flash('Sua senha deve conter no minimo 6 caracteres')
            else:
                flash('Seu email precisa de no minimo 6 caracteres.')

    return render_template('registro.html') 


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    user_logged_in = 'user_id' in session  # Verifica se o usuário está logado
    return render_template('profile.html', user_logged_in=user_logged_in)

####################################################################################################

create_table()
if __name__ == "__main__":
    app.run(debug=True)
